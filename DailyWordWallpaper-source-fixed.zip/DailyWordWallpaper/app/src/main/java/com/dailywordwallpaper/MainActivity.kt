package com.dailywordwallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PREFS = "daily_word_settings"
private const val KEY_INTERVAL = "rotation_interval_minutes"
private const val KEY_STYLE = "wallpaper_style"
private const val KEY_SELECTED = "selected_wallpaper_index"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DailyWordApp(this) }
    }
}

private data class VerseWallpaper(
    val title: String,
    val verse: String,
    val reference: String,
    val colors: List<Color>
)

private val wallpapers = listOf(
    VerseWallpaper("Morning light", "The Lord is my shepherd; I shall not want.", "Psalm 23:1 · KJV", listOf(Color(0xFF172B4D), Color(0xFF527A9A), Color(0xFFE8B879))),
    VerseWallpaper("Peaceful waters", "Peace I leave with you, my peace I give unto you.", "John 14:27 · KJV", listOf(Color(0xFF123B45), Color(0xFF397C78), Color(0xFFB6C9A8))),
    VerseWallpaper("Strength for today", "I can do all things through Christ which strengtheneth me.", "Philippians 4:13 · KJV", listOf(Color(0xFF33234F), Color(0xFF765B91), Color(0xFFD7A5A0))),
    VerseWallpaper("New mercies", "His compassions fail not. They are new every morning.", "Lamentations 3:22–23 · KJV", listOf(Color(0xFF563C32), Color(0xFFB36C4D), Color(0xFFE7BD83)))
)

@Composable
private fun DailyWordApp(activity: Activity) {
    val prefs = remember { activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var interval by remember { mutableIntStateOf(prefs.getInt(KEY_INTERVAL, 5)) }
    var style by remember { mutableStateOf(prefs.getString(KEY_STYLE, "Mixture") ?: "Mixture") }
    var selected by remember { mutableIntStateOf(prefs.getInt(KEY_SELECTED, 0).coerceIn(0, wallpapers.lastIndex)) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFE6C58A), background = Color(0xFF101820), surface = Color(0xFF1B2732)
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF101820)) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFE6C58A), modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Daily Word Wallpaper", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Let the Word brighten your day", color = Color(0xFFB7C2CC), fontSize = 12.sp)
                    }
                }

                Text("Your scripture wallpaper", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                WallpaperPreview(wallpapers[selected])

                Text("Explore designs", color = Color.White, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(wallpapers.indices.toList()) { index ->
                        val item = wallpapers[index]
                        Surface(
                            onClick = {
                                selected = index
                                prefs.edit().putInt(KEY_SELECTED, index).apply()
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected == index) Color(0xFF344657) else Color(0xFF1B2732),
                            border = if (selected == index) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE6C58A)) else null
                        ) {
                            Column(Modifier.width(132.dp).padding(12.dp)) {
                                Box(Modifier.fillMaxWidth().height(66.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(item.colors)))
                                Spacer(Modifier.height(8.dp))
                                Text(item.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFFE6C58A))
                    Spacer(Modifier.width(8.dp))
                    Text("Automatic wallpaper change", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(5, 10, 15).forEach { minutes ->
                        FilterChip(
                            selected = interval == minutes,
                            onClick = {
                                interval = minutes
                                prefs.edit().putInt(KEY_INTERVAL, minutes).apply()
                            },
                            label = { Text("$minutes min") },
                            leadingIcon = { if (interval == minutes) { Icon(Icons.Default.CheckCircle, null, Modifier.size(16.dp)) } }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = Color(0xFFE6C58A))
                    Spacer(Modifier.width(8.dp))
                    Text("Visual style", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text(style, color = Color(0xFFE6C58A))
                }
                Text("Mixture of peaceful nature, elegant minimal and inspirational designs.", color = Color(0xFFB7C2CC), fontSize = 12.sp)

                Button(
                    onClick = {
                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                ComponentName(activity, DailyWallpaperService::class.java))
                        }
                        activity.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE6C58A), contentColor = Color(0xFF17212B))
                ) { Text("Set as live wallpaper", fontWeight = FontWeight.Bold) }
                Text("Early foundation build · More features are coming", color = Color(0xFF82909B), fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun WallpaperPreview(item: VerseWallpaper) {
    Box(
        modifier = Modifier.fillMaxWidth().height(245.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(item.colors)),
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("DAILY WORD", color = Color.White.copy(alpha = .78f), fontSize = 10.sp, letterSpacing = 3.sp)
            Text(item.verse, color = Color.White, fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Text(item.reference, color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
        }
    }
}
