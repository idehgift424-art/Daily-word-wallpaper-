# Daily Word Wallpaper — Android foundation (Redmi A5-friendly)

A Kotlin + Jetpack Compose starter for a scripture-based live wallpaper app. The project uses a lightweight, offline-first foundation and a simple gradient renderer so the first build does not need to download large wallpaper images.

## Included
- Android app shell and Compose interface
- Four built-in KJV scripture wallpaper designs
- 5, 10 and 15-minute rotation choices
- Android Live Wallpaper service and system preview/set flow
- Saved rotation interval and selected wallpaper
- Mixed visual direction: peaceful color gradients, elegant typography and inspirational scripture
- GitHub Actions workflow to build a debug APK in the cloud (no laptop required)

## Redmi A5 considerations
- The interface is vertically scrollable for smaller effective display sizes and larger system font settings.
- The initial wallpaper artwork is drawn locally rather than streamed, reducing data use and memory pressure.
- The app does not need an account or network connection for its starter features.
- Redmi/Xiaomi battery management may pause background work. A live wallpaper is managed by Android and can be paused when it is not visible; exact rotation timing is therefore not guaranteed in every device state.

## Build from an Android phone using GitHub Actions
1. Create a GitHub account if you do not already have one.
2. In your browser, create a new public or private repository named `DailyWordWallpaper`.
3. Upload the contents of this project folder to the repository (upload the files and folders inside this folder, not the ZIP itself).
4. Open the repository's **Actions** tab and enable GitHub Actions if prompted.
5. Select **Build Android APK** and tap **Run workflow**. A push to the `main` branch also starts a build.
6. When the workflow finishes successfully, open that run and download the `daily-word-wallpaper-debug-apk` artifact.
7. Extract the downloaded artifact and install `app-debug.apk` on the Redmi A5. Android may ask you to allow installation from the browser or file manager you used. Only install APKs you built from your own trusted repository.

The GitHub workflow uses Gradle 8.9 and Java 17 to run `assembleDebug` and uploads the resulting APK. Cloud build access and artifact retention are controlled by GitHub and its current account limits.

## Open and run on a computer
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Connect an Android device or use an emulator, then press Run.

## Important foundation-stage notes
- This is source code, not a signed release APK or Play Store AAB. It has not yet been compiled or tested on a physical Redmi A5.
- The wallpaper service rotates while Android keeps the wallpaper engine active/visible. Android and manufacturer battery controls may pause wallpaper engines to conserve power; exact timing is not guaranteed when the engine is not active.
- Current wallpaper backgrounds are generated gradients with bundled KJV verse text. Downloadable photo collections, remote content management, NIV licensing/permission, accounts, AdMob, premium billing, privacy policy, app icon and Play Store release preparation are later milestones.
- NIV is copyrighted. Do not bundle NIV text in a commercial app without obtaining the appropriate permission/licence. The starter uses KJV.
- Before public release, test on multiple Android versions and devices, optimize battery use, review current Play target SDK requirements, and complete Google Play policy declarations.

## Project details
- Package: `com.dailywordwallpaper`
- Minimum Android: API 23 (Android 6.0)
- Compile/target SDK: 35
- Language: Kotlin
- UI: Jetpack Compose
